
<?php
include "includes/db.inc.php";
session_start();
include 'header.php';
$uid=$_SESSION['userid'];
$uname=$_SESSION['userUid'];


$result=mysqli_query($conn,"SELECT * FROM users WHERE idusers='$uid'");
$retrieve=mysqli_fetch_array($result);
//print_r($retrieve);

$id=$retrieve['idusers'];
$uid=$retrieve['uidusers'];
$emailusers=$retrieve['emailusers'];
$address=$retrieve['address'];
$gender=$retrieve['gender'];
$number=$retrieve['number'];
$profilepic=$retrieve['profilepic'];
$firstname=$retrieve['firstname'];
$lastname=$retrieve['lastname'];
$bio=$retrieve['bio'];
$workedu=$retrieve['work_edu'];


?>


<!DOCTYPE html>

<html>

<head>

<title> Assignment 3 Form </title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<!--<link rel="stylesheet"  href="css/profprodcard.css"> -->
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet"  href="css/stylingteam.css">
</head>



<body bgcolor="#E6E6FA">

<h2 style="text-align:center">User Profile Card</h2>






	<div class="page-content">
		<div class="form-v8-content">
			<div class="form-left">
				 
  <?php echo "<img style='width:98%' src='includes/".$retrieve['profilepic']."'>"; ?>
			</div>
			<div class="form-right">
				
			
					
						
							<label>
							ID NO
							
							</label>
		<div>		 <h1>  <?php echo $id; ?> </h1>   </div>
  <h2>  <?php echo $uid; ?>      </h2> <br>
  <p class="title">CEO & Founder, Example</p> <br>
  
  <p class="title"> <?php echo $workedu; ?>  </p> <br>
  <p class="title"> <?php echo $emailusers; ?>  </p> <br>
    <p class="title"> <?php echo $address; ?>  </p> <br>
    <p class="title"> <?php echo $gender; ?> <br>
    <p class="title"> <?php echo $number; ?> <br>
	   <p class="title"> <?php echo $firstname; ?>  </p> <br>
    <p class="title"> <?php echo $lastname; ?> <br>
    <p class="title"> <?php echo $bio; ?>
	
	
<!--<button type="submit" onclick="http://localhost/Pawesome/profpageedit.php" name="profpageedit" class="btn btn-success">EDIT PROFILE</button>
	-->

  <p><a href="profpageedit.php"> EDIT PROFILE </a> </p>	
				

		</div>
	</div>

</div>




</body>


<?php 


include 'footer.php';

?>

</html>
