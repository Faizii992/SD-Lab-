
<?php
session_start();
include 'header.php';


?>


<!DOCTYPE html>

<head>

<title> Assignment 3 Form </title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link rel="stylesheet"  href="css/main.css">
<link rel="stylesheet" href="css/bootstrap.min.css">
</head>




<body>




<div class="col-md-12">





<div class="box">




	 
				<?php	 
					 if(isset($_SESSION['userid']))
{
	$uid=$_SESSION['userid'];
$uname=$_SESSION['userUid'];


echo '<h1> User Profile Page </h1> ';

	  echo'<div class="firstlastname">

<form action="includes/placeorder.inc.php" method="post" enctype="multipart/form-data">


<div class="name">

  ';

?> 


    <label> YOUR NAME </label>
   <label>  <?php echo $uname; ?> </label>
   
   <label>  YOUR EMAIL * </label>
   <label>  <?php echo $uid; ?> </label>

<label> YOUR ADDRESS * </label>
   <label>  <?php echo $uname; ?> </label>

<label> ENTER number* </label>
   <label>  <?php echo $uname; ?> </label>

  <?php
  
 echo' 
 
 
 
 <div class="firstlastnamediv">



</div>

</div>

<label> Add payment Method * </label>
<div class="radi" width="10px">
<input type="radio" name="paymentmethod" value="BKASH"> BKASH <br>
<input type="radio" name="paymentmethod" value="CREDIT CARD"> CREDIT CARD <br>
</div>


<label> Any Special Notes? * </label>
<div class="messagebox">
<textarea name="specialnotes"  class="form-control">Write a special note...</textarea>
</div>

<div class="button">
<button type="submit" name="placeorder" class="btn btn-default"> PLACE ORDER! </button>

</div>
</form>

</div>';
	
	
}
else
{
	

	
				echo' <div class="alert alert-danger">
  <strong>NOT AVAILABLE</strong> You need to Log In to avail this feature! 
</div> ';
			
	
}


?>

</div>

</div>


</body>


<?php

include 'footer.php';

?>

</html>
