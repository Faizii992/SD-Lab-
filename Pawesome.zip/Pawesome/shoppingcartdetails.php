
<?php
  session_start();
	require 'includes/db.inc.php';
	include 'header.php';

?>



   

<!doctype html>

<html>

<head>
<title>
170104093

</title>


<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

<link rel="stylesheet" type="text/css" href="css/shoppingpage.css">
<link rel="stylesheet" href="css/bootstrap.min.css">

</head>

<body>







            <?php
                if(!empty($_SESSION["cart"])){
                    
					
					
 echo ' <h3 class="title2">Shopping Cart Details</h3>
        <div class="table-responsive">
            <table class="table table-bordered">
            <tr>
                <th width="30%">Product Name</th>
                <th width="10%">Quantity</th>
                <th width="13%">Price Details</th>
                <th width="10%">Total Price</th>
                <th width="17%">Remove Item</th>
            </tr>
			
			';
					
					$total = 0;
                    foreach ($_SESSION["cart"] as $key => $value) {
                        ?>
                        <tr>
                            <td><?php echo $value["product_name"]; ?></td>
                            <td><?php echo $value["product_qty"]; ?></td>
                            <td>$ <?php echo $value["product_price"]; ?></td>
                            <td>
                                $ <?php echo number_format($value["product_qty"] * $value["product_price"], 2); ?></td>
                            <td><a href="shoppingpage2.php?action=delete&id=<?php echo $value["product_id"]; ?>"><span
                                        class="text-danger">Remove Item</span></a></td>

                        </tr>
                        <?php
                        $total = $total + ($value["product_qty"] * $value["product_price"]);
                    }
                        ?>
                        <tr>
                            <td colspan="3" align="right">Total</td>
                            <th align="right">$ <?php echo number_format($total, 2); ?></th>
                            <td></td>
                        </tr>
                
            </table>
        </div>

<button onclick="location.href = 'http://localhost/Pawesome/proceedtocheckout.php';" type="button" class="btn btn-success">Proceed To Checkout</button>

<?php
				}
				else
					
					{
						
					
				?>
				
				
				
				
				<?php
				
				
				echo' <div class="alert alert-success">
  <strong>Empty Cart!!</strong> There is nothing on the cart  <a href="shoppingpage2.php"> Click Here to order!! </a>
</div> ';
				
					}
					
					
					
					?>

<button onclick="location.href = 'http://localhost/Pawesome/shoppingpage2.php';" type="button" class="btn btn-warning">Add Items!</button>
</body>


</html>


<?php

include 'footer.php';

?>
