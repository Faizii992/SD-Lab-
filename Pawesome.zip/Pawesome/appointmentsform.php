<?php

include 'header.php';
//$uid=$_SESSION['userid'];
//$uname=$_SESSION['userUid']
//include 'header.php';

?>



<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">

	<!-- Mobile Specific Metas -->
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<!-- Font-->
	<link rel="stylesheet" type="text/css" href="css/sourcesanspro-font.css">
	<!-- Main Style Css -->
    <link rel="stylesheet" href="css/stylingcontact.css"/>
</head>
<body class="form-v8">
	<div class="page-content">
		<div class="form-v8-content">
			<div class="form-left">
				<img src="images/vet1.jpg" >
			</div>
			<div class="form-right">
				<div class="tab">
					<div class="tab-inner">
						<button class="tablinks" id="defaultOpen"> TELL US WHATS WRONG </button>
					</div>
				
				</div>
				<form class="form-detail" action="includes/appointments.inc.php" method="post">
					<div class="tabcontent" id="sign-up">
					
					
					
				<?php	
					
				
					
									 if(isset($_SESSION["userid"]))
{
		
		
		
		
	 echo'					
						<div class="form-row">
							<label class="form-row-inner">
							<span class="label">Username</span>
								<input type="text" name="username" value=';
								echo $uname; 
								echo' <br>
								
		  						<span class="border"></span>
							</label>
						</div>
						
						<div class="form-row">
							<label class="form-row-inner">
								<input type="text" name="email"  class="input-text" required>
								<span class="label">E-Mail</span>
		  						<span class="border"></span>
							</label>
						</div>
						';	
}
else
{		 
	  echo'					
						<div class="form-row">
							<label class="form-row-inner">
								<input type="text" name="username"  class="input-text" required>
								<span class="label">Username</span>
		  						<span class="border"></span>
							</label>
						</div>
						
						<div class="form-row">
							<label class="form-row-inner">
								<input type="text" name="email"  class="input-text" required>
								<span class="label">E-Mail</span>
		  						<span class="border"></span>
							</label>
						</div>
						';	
}
				
			?>		
					
				
						<div class="form-row">
							<label class="form-row-inner">
								<input type="text" name="subject"  class="input-text" required>
								<span class="label">Subject</span>
								<span class="border"></span>
							</label>
						</div>
					
						<div class="form-row">
							<label class="form-row-inner">
								<input type="text" name="message"  class="input-text" required>
								<span class="label">Message</span>
								<span class="border"></span>
							</label>
						</div>
						<div class="form-row-last">
							<input type="submit" name="register" class="register" value="CREATE APPOINTMENT">
						</div>
					</div>
				</form>
				
				
				
				
			
			</div>
		</div>
	</div>
	
</body>
</html>