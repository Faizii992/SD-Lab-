<!doctype html>

<html>

<head>
<title>
170104093

</title>


<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">

<link rel="stylesheet" href="css/bootstrap.min.css">

</head>

<body>

<div class="secondcont">
<button class="w3-button w3-circle w3-khaki" style="margin-left: 50% " style="margin-bottom: 20%" align="center"><a href="#"> 🠉</a></button>

<div class="container">
<div class="row">



<div class="col-md-3 col-sm-6"> 



<div class="box">
<div class="scndcontimg">


</div>

<h1> PAwesome Care </h1>

<p>We are here to speak on behalf of the ones who cant..</p>

<div class="secondbox">
  

  
  </div>
  </div>
 
</div>

<div class="col-md-3 col-sm-6"> 



<div class="box">
<div class="scndcontimg">


</div>

<h1>Menu</h1>

<ul style="list-style-type:none;">

<li><a href="shoppingcart2.php"> </a> Shop </li>
<li><a href="shoppingcart2.php"> </a> Journal</li>
<li><a href="shoppingcart2.php"> </a> About</li>
<li><a href="contactpage.php"> </a> Contact </li>

</ul>

<div class="secondbox">
  

  
  </div>
  </div>
 
</div>


<div class="col-md-3 col-sm-6"> 



<div class="box">
<div class="scndcontimg">


</div>

<h1>Help</h1>

<ul style="list-style-type:none;">

<li><a href="shoppingcart2.php"> </a> Shipping Information </li>
<li><a href="shoppingcart2.php"> </a> Returns and Exchange </li>
<li><a href="shoppingcart2.php"> </a> Terms and conditions</li>
<li><a href="contactpage.php"> </a> Privacy policy </li>

</ul>

<div class="secondbox">
  

  
  </div>
  </div>
 
</div>


<div class="col-md-3 col-sm-6"> 



<div class="box">
<div class="scndcontimg">


</div>

<h1>Have Questions? </h1>


<ul style="list-style-type:none;">
<li>203 Fake St. Mountain View, San Francisco, California, USA</li>
<li>+2 392 3929 210</li>
<li>info@yourdomain.com</li>

</ul>

<div class="secondbox">
  


  
  </div>
  </div>
 
</div>


</div>
</div>
</div>



<div style="background-color:#CDE2BB;" class="footer">

<h4 style="padding: 20px" align="middle"> © Copyright 2017 All Rights Reserved </h1>
</div>

</body>


</html>