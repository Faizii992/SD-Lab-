
<?php


//session_start();

?>



<!DOCTYPE html>

<head>

<title> pAwesome Care </title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link rel="stylesheet" type="text/css" href="css/header2.css">
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/swiper.min.css">
<link rel="stylesheet" href="css/swiper.css">
   



</head>



<body>

<div class="stickyheader">
<?php
	
if(isset($_SESSION['userid']))
{
	

	echo'

	<div class="topnav">
<div class="login_container">
    <form class="form-inline" action="includes/logout.inc.php">
      
      <button id="logout" width="100px" class="btn btn-default" type="submit">LOG OUT</button>
	 
    </form>
  </div>

</div>


<div id="navbar">
  <a href="#home">Home</a>
  <a href="#news">News</a>
  <a href="#contact">Contact</a>
</div>

  
  ';
  
	
}
else
{
	
	
		echo '
		
		
		<div class="topnav">
<div class="login_container">
    <form class="form-inline" action="includes/login.inc.php">
      
	  
	  
	  
      <button id="login" width="200px" class="btn btn-default" type="submit">Login</button>
	   <button id="register" class="btn btn-default" type="submit">Register</button>
    </form>
  </div>

</div>



<div id="navbar">
  <a href="#home">Home</a>
  <a href="#news">News</a>
  <a href="#contact">Contact</a>
</div>

  
  ';
  


	
}



?>



</div>


<div class="logowithinfo">
<img src="images/logomain.png">


<div class="infobox">

<img src="images/icon4.png">

<div class="info">
<h1> OUR LOCATION </h1>
<p> 2418,NANCY NY </p>

</div>

</div>

<div class="infobox">

<img src="images/icon4.png">
<div class="info">
<h1> OUR LOCATION </h1>
<p> 2418,NANCY NY </p>

</div>
</div>

<div class="infobox">

<img src="images/icon4.png">
<div class="info">
<h1> OUR LOCATION </h1>
<p> 2418,NANCY NY </p>

</div>
</div>

</div>

<center>

  </center>
  
</body>



</html>

