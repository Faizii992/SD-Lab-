<?php
    session_start();
include 'header.php';

?>


<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">

	<!-- Mobile Specific Metas -->
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<!-- Font-->
	<link rel="stylesheet" type="text/css" href="css/sourcesanspro-font.css">
	<!-- Main Style Css -->
    <link rel="stylesheet" href="css/stylingcontact.css"/>
</head>
<body class="form-v8">
	<div class="page-content">
		<div class="form-v8-content">
			<div class="form-left">
				<img src="images/shiro.jpg" >
			</div>
			<div class="form-right">
				<div class="tab">
					<div class="tab-inner">
						<button class="tablinks" id="defaultOpen">SEND US A MESSAGE</button>
					</div>
				
				</div>
				<form class="form-detail" action="includes/messages.inc.php" method="post">
					<div class="tabcontent" id="sign-up">
						<div class="form-row">
							<label class="form-row-inner">
								<input type="text" name="username"  class="input-text" required>
								<span class="label">Username</span>
		  						<span class="border"></span>
							</label>
						</div>
						<div class="form-row">
							<label class="form-row-inner">
								<input type="text" name="email"  class="input-text" required>
								<span class="label">E-Mail</span>
		  						<span class="border"></span>
							</label>
						</div>
						
						<div class="form-row">
							<label class="form-row-inner">
								<input type="text" name="subject"  class="input-text" required>
								<span class="label">Subject</span>
								<span class="border"></span>
							</label>
						</div>
					
						<div class="form-row">
							<label class="form-row-inner">
								<input type="text" name="message"  class="input-text" required>
								<span class="label">Message</span>
								<span class="border"></span>
							</label>
						</div>
						
							<button type="submit" name="register" class="btn btn-info">Send Us A Message!</button>
						
					</div>
				</form>
				
				
				
				
			
			</div>
		</div>
	</div>
	
</body>
</html>



<?php

include 'footer.php';

?>