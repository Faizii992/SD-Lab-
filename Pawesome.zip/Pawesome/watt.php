<!DOCTYPE html>
<html>
<head>
 <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet"
href="css\bootstrap.min.css" />


</head>

<body>
<?php
$error='';
$firstname ='';
$laststname ='';
$email='';
$no='';
$comment='';

function clean_text($string)
{
 $string = trim($string);
 $string = stripslashes($string);
 $string = htmlspecialchars($string);
 return $string;
}


  $firstname = clean_text($_POST["firstname"]); 
  $lastname = clean_text($_POST["lastname"]);
  $email = clean_text($_POST["email"]);
  $no = clean_text($_POST["no"]);
   $comment = $_POST["comment"];
  $file_open = fopen("wat.csv", "a");
  $no_rows = count(file("wat.csv"));
  $form_data = array(
   'id'  => $no_rows+1,
   'firstname'  => $firstname,
    'lastname'  => $lastname,
   'email'  => $email,
   'no' => $no,
   'comment'=> $comment,
  );
  fputcsv($file_open, $form_data);
  $firstname = '';
     $laststname = '';
  $email = '';
  $no = '';
  $comment = '';
  

?>
<div class="container">
  <table class="table table-bordered">
  <thead>
  <tr>
      <th> ID </th>
  <th>First Name</th>
    <th>Last Name</th>
  <th>Email</th>
  <th>Phone Number</th>
    <th>Message</th>
</tr>
<tbody>


	<?php
		
        $fp=fopen('wat.csv','r');
		 $fs=filesize('wat.csv');
		 $separator=",";
		
		 while($row=fgetcsv($fp,$fs,$separator))
		 { echo '<tr>';
			 
			 echo '<td>'.$row[0].'</td>';
			  echo '<td>'.$row[1].'</td>';
			  echo '<td>'.$row[2].'</td>';
          echo '<td>'.$row[3].'</td>';
		  	  echo '<td>'.$row[4].'</td>';
          echo '<td>'.$row[5].'</td>';
			  echo'</tr>';
		 }  
		 
		 
			
	   
		?>
		</tbody>
		</table>
		
</div>
</body>
</html>











<!--



fgetcsv(file, length, separator, enclosure)
Parameter	Description
file	Required. Specifies the open file to return and parse a line from
length	Optional. Specifies the maximum length of a line. Must be greater than the longest line (in characters) in the CSV file. Omitting this parameter (or setting it to 0) the line length is not limited, which is slightly slower. Note: This parameter is required in versions prior to PHP 5
separator	Optional. Specifies the field separator. Default is comma ( , )
enclosure	Optional. Specifies the field enclosure character. Default is "
escape	Optional. Specifies the escape character. Default is "\\"



-->