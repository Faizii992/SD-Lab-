<?php

	require 'db.inc.php';



if(isset($_POST['inputbtn']))
{
	
	
	
	$target_dir = "product_img/";
$target_file = $target_dir . basename($_FILES["product_img"]["name"]);
move_uploaded_file ($_FILES["product_img"]["tmp_name"], $target_file);
		
	//$id=$POST['id'];
//$result=mysqli_query($conn,"UPDATE 'users' SET emailusers='$_POST['email']',address='$_POST['address']',gender='$_POST['gender']',number='$_POST['number']',profilepic='$_FILES['profilepic']',firstname='$_POST['firstname']',lastname='$_POST['lastname']',bio='$_POST['bio']' WHERE idusers='$uid'");

$result=mysqli_query($conn,"INSERT into product_details VALUES
('','$_POST[product_name]','$target_file','$_POST[product_category]',$_POST[product_price],$_POST[product_qty],'$_POST[product_desc]')");


}


?>


<!DOCTYPE html>


<head>

<title> Inp</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link rel="stylesheet"  href="css/profpagecard.css">
<link rel="stylesheet" href="css/bootstrap.min.css">
</head>



<body>

	
	</body>
	
	
	</html>