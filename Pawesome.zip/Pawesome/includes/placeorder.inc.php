<?php


	require 'db.inc.php';
	
	session_start();
if(isset($_POST['placeorder']))
{
$uid=$_SESSION['userid'];
$email=$_SESSION['email'];
	$address=$_SESSION['address'];
$number=$_SESSION['number'];
		//$paymentmethod=$_POST['paymentmethod'];
$specialnotes=$_POST['specialnotes'];
	
	
$orderdate=date("Y-m-d");	
$ordertime=date("H:i:s");	

	//$id=$POST['id'];
//$result=mysqli_query($conn,"UPDATE 'users' SET emailusers='$_POST['email']',address='$_POST['address']',gender='$_POST['gender']',number='$_POST['number']',profilepic='$_FILES['profilepic']',firstname='$_POST['firstname']',lastname='$_POST['lastname']',bio='$_POST['bio']' WHERE idusers='$uid'");
$totalqty=0;
$productnames="";
print_r($_SESSION["cart"]);


    if(!empty($_SESSION["cart"])){
                    $total = 0;
                    foreach ($_SESSION["cart"] as $key => $value) {
                       
                      $totalqty+=$value['product_qty'];
                            $productnames.=$value['product_name']." ";
                                 number_format($value["product_qty"] * $value["product_price"], 2);
                            
                      
                       
                        $total = $total + ($value["product_qty"] * $value["product_price"]);
                    }
                        
                        
                           
                         
                    }




//$resultset=mysqli_query($conn,"INSERT into ordertwo(order_id,date,time,customername,customer_email,product_qty,product_name,totalprice,customer_address,customer_number,paymentmethod,special_note) VALUES
//('','$orderdate','$ordertime','$uid','$email',$totalqty,'$productnames',$total,'$address',$number,'$paymentmethod,'$specialnotes')");


$resultset=mysqli_query($conn,"INSERT into ordertwo(order_id,date,time,customername,customer_email,product_qty,product_name,totalprice,customer_address,special_note) VALUES
('','$orderdate','$ordertime','$uid','$email',$totalqty,'$productnames',$total,'$address','$specialnotes')");
 unset($_SESSION['cart']);
//$result=mysqli_query($conn,"INSERT into order_details VALUES
//('','$orderdate','$ordertime','$_POST[product_category]',$_POST[product_price],$_POST[product_qty],'$_POST[product_desc]')");


  if(empty($_SESSION["cart"])){
	  
	 // echo '<script>window.location="../shoppingpage2.php"</script>';
	  
  }


}


?>


<!DOCTYPE html>


<head>

<title> Inp</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link rel="stylesheet"  href="css/profpagecard.css">
<link rel="stylesheet" href="css/bootstrap.min.css">
</head>



	
	
	</html>