
<?php

session_start();
$uid=$_SESSION['userid'];
$uname=$_SESSION['userUid']


?>


<!DOCTYPE html>

<head>

<title> Assignment 3 Form </title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link rel="stylesheet"  href="css/main.css">
<link rel="stylesheet" href="css/bootstrap.min.css">
</head>





<body>



<div class="col-md-6 rightdiv">





<div class="box">



<h1> User Profile Page </h1>



	 
				<?php	 
					 if(isset($_SESSION['userid']))
{
	
	  echo'<div class="firstlastname">

<form action="includes/updateusers.inc.php" method="post" enctype="multipart/form-data">


<label> ENTER YOUR PIC* </label>
<input type="file" class="form-control" name="profilepic" placeholder="example@example" />
<div class="name">
<label> TELL US YOUR NAME *</label>

<div class="firstlastnamediv">

 <div class="firstname">  <input  type="text" name="firstname" class="form-control"  value="$uid" /> </div>

 <div class="lastname"> <input type="text" name="lastname" class="form-control" placeholder=$email /> </div>


</div>

</div>

<label> ENTER YOUR EMAIL * </label>
<input type="email" class="form-control" name="email" placeholder="example@example" />

<label> ENTER ADDRESS * </label>
<input type="text" class="form-control" name="address" placeholder="Eg-1800 0000" />

<label> ENTER PHONE NUMBER * </label>
<input type="number" class="form-control" name="number" placeholder="Eg-1800 0000" />



<label> Bio * </label>
<div class="messagebox">
<textarea name="bio"  class="form-control">Write us a message.</textarea>
</div>

<div class="button">
<button type="submit" name="savechanges" class="btn btn-default"> SAVE CHANGES </button>

</div>
</form>

</div>';
	
	
}
else
{
	
		 
	  echo'
<div class="firstlastname">

<form action="watt.php" method="post">


<div class="name">
<label> TELL US YOUR NAME *</label>

<div class="firstlastnamediv">

 <div class="firstname">  <input  type="text" name="firstname" class="form-control"  placeholder="Firstname" /> </div>

 <div class="lastname"> <input type="text" name="lastname" class="form-control" placeholder="Lastname" /> </div>

</div>

</div>

<label> ENTER YOUR EMAIL * </label>
<input type="email" class="form-control" name="email" placeholder="example@example.com" />


<label> ENTER PHONE NUMBER * </label>
<input type="number" class="form-control" name="no" placeholder="Eg-1800 0000" />


<label> Bio * </label>
<div class="messagebox">
<textarea name="comment"  class="form-control">Write us a message.</textarea>
</div>

<div class="button">
<button type="submit" name="submit" class="btn btn-default"> SEND MESSAGE </button>

</div>
</form>

</div>';
	
}


?>

</div>

</div>


</body>




</html>
