

<!doctype html>

<html>

<head>
<title>
170104093

</title>


<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

<link rel="stylesheet" type="text/css" href="css/assignment2.css">
<link rel="stylesheet" href="css/bootstrap.min.css">

</head>

<body>



<?php 
    session_start();
include 'header.php';

?>


<div class="firstcont">

<div class="container">
<div class="row">

<div class="col-md-4 col-sm-6"> 
<div class="box">
<h1> Highly Secure </h1>
<img src="Images/icon1.png">
<p>Cloud based services can offer our customers tenant dedicated environments</p>
  </div>
</div>
<div class="col-md-4 col-sm-6"> 
<div class="box">
<h1> True Cloud Sale </h1>
<img src="Images/icon2.png">
<p> Working with customers making 100-40,000 hires per annum </p>
  </div>
</div>
<div class="col-md-4 col-sm-6"> 
<div class="box">
<h1> Accurate Data </h1>
<img src="Images/icon3.png">
<p> All of our customers data is validated. We build accurate data banks for reporting </p>
  </div>
</div>


</div>

</div>

</div>




</div>


<div class="seconddiv">
<div class="blogpostheader">
<p class="MEET"> OUR </p>
<h1 class="OUR_VETS"> PRICES </h1>

</div>



<div class="secondcont">

<div class="container">
<div class="row">

<div class="col-md-4 col-sm-6"> 



<div class="box">
<div class="scndcontimg">

<img src="Images/vet1.jpg">
</div>

<h2> $200 </h2>

<h1>First Appointment </h1>

<hr>

<ul>

<li> Medical History </li>
<li> Physical Exam </li>
<li> Diagnosis and prescription </li>


</ul>

<div class="secondbox">


  


<div class="button">
<button type="submit" onclick="location.href = 'http://localhost/Pawesome/appointmentsform.php';" name="submit" class="btn btn-default"> CREATE AN APPOINTMENT </button>

</div> 
  </div>
  </div>

  
</div>



<div class="col-md-4 col-sm-6"> 



<div class="box">
<div class="scndcontimg">

<img src="Images/vet1.jpg">
</div>

<h2> $200 </h2>

<h1>First Appointment </h1>

<hr>

<ul>

<li> Medical History </li>
<li> Physical Exam </li>
<li> Diagnosis and prescription </li>


</ul>

<div class="secondbox">


  


<div class="button">
<button type="submit" onclick="location.href = 'http://localhost/Pawesome/proceedtocheckout.php';" name="submit" class="btn btn-default"> CREATE AN APPOINTMENT </button>

</div> 
  </div>
  </div>

  
</div>




<div class="col-md-4 col-sm-6"> 



<div class="box">
<div class="scndcontimg">

<img src="Images/vet1.jpg">
</div>

<h2> $200 </h2>

<h1>First Appointment </h1>

<hr>

<ul>

<li> Medical History </li>
<li> Physical Exam </li>
<li> Diagnosis and prescription </li>


</ul>

<div class="secondbox">


  


<div class="button">
<button type="submit" onclick="location.href = 'http://localhost/Pawesome/proceedtocheckout.php';" name="submit" class="btn btn-default"> CREATE AN APPOINTMENT </button>

</div> 
  </div>
  </div>

  
</div>



<div class="col-md-4 col-sm-6"> 



<div class="box">
<div class="scndcontimg">

<img src="Images/vet1.jpg">
</div>

<h2> $200 </h2>

<h1>First Appointment </h1>

<hr>

<ul>

<li> Medical History </li>
<li> Physical Exam </li>
<li> Diagnosis and prescription </li>


</ul>

<div class="secondbox">


  


<div class="button">
<button type="submit" onclick="location.href = 'http://localhost/Pawesome/proceedtocheckout.php';" name="submit" class="btn btn-default"> CREATE AN APPOINTMENT </button>

</div> 
  </div>
  </div>

  
</div>



<div class="col-md-4 col-sm-6"> 



<div class="box">
<div class="scndcontimg">

<img src="Images/vet1.jpg">
</div>

<h2> $200 </h2>

<h1>First Appointment </h1>

<hr>

<ul>

<li> Medical History </li>
<li> Physical Exam </li>
<li> Diagnosis and prescription </li>


</ul>

<div class="secondbox">


  


<div class="button">
<button type="submit" onclick="location.href = 'http://localhost/Pawesome/proceedtocheckout.php';" name="submit" class="btn btn-default"> CREATE AN APPOINTMENT </button>

</div> 
  </div>
  </div>

  
</div>



<div class="col-md-4 col-sm-6"> 



<div class="box">
<div class="scndcontimg">

<img src="Images/vet1.jpg">
</div>

<h2> $200 </h2>

<h1>First Appointment </h1>

<hr>

<ul>

<li> Medical History </li>
<li> Physical Exam </li>
<li> Diagnosis and prescription </li>


</ul>

<div class="secondbox">


  


<div class="button">
<button type="submit" onclick="location.href = 'http://localhost/Pawesome/proceedtocheckout.php';" name="submit" class="btn btn-default"> CREATE AN APPOINTMENT </button>

</div> 
  </div>
  </div>

  
</div>

 
</div>



 
</div>



</div>

</div>

</div>

</div>






<div class="thirddiv">
<div class="blogpostheader">
<p class="MEET"> MEET </p>
<h1 class="OUR_VETS"> OUR VETS </h1>

</div>



<div class="secondcont">

<div class="container">
<div class="row">

<div class="col-md-3 col-sm-6"> 



<div class="box">
<div class="scndcontimg">

<img src="Images/vete.jpg">
</div>

<h1>Dr. Joseph Tribbiani </h1>



  
</div>

</div>
<div class="col-md-3 col-sm-6"> 



<div class="box">
<div class="scndcontimg">

<img src="Images/vetf.jpg">
</div>
<h1>Dr. Joseph Tribbiani </h1>
  </div>

  
</div>



<div class="col-md-3 col-sm-6"> 



<div class="box">
<div class="scndcontimg">

<img src="Images/veta.jpg">
</div>

<h1>Dr. Joseph Tribbiani </h1>
  </div>
 
</div>


<div class="col-md-3 col-sm-6"> 



<div class="box">
<div class="scndcontimg">

<img src="Images/vetf.jpg">
</div>

<h1>Dr. Joseph Tribbiani </h1>
  </div>
 
</div>


<div class="col-md-3 col-sm-6"> 



<div class="box">
<div class="scndcontimg">

<img src="Images/vet3.jpg">
</div>

<h1>Dr. Joseph Tribbiani </h1>
  </div>
 
</div>



<div class="col-md-3 col-sm-6"> 



<div class="box">
<div class="scndcontimg">

<img src="Images/vet2.jpg">
</div>

<h1>Dr. Joseph Tribbiani </h1>
  </div>
 
</div>




<div class="col-md-3 col-sm-6"> 



<div class="box">
<div class="scndcontimg">

<img src="Images/vet3.jpg">
</div>

<h1>Dr. Joseph Tribbiani </h1>
  
  
  </div>
 
</div>






<div class="col-md-3 col-sm-6"> 



<div class="box">
<div class="scndcontimg">

<img src="Images/vetf.jpg">
</div>

<h1>Dr. Joseph Tribbiani </h1>
  </div>
 
</div>



</div>

</div>

</div>

</div>








<div class="QuestionsandAnswers">
<p class="QandA"> QUESTIONS AND ANSWERS </p>
<h1 class="freqAskedQ"> Frequently Asked Questions </h1>

<div class="QandAcontainer">

</div>
</div>




<div class="footer">

<h1> © Copyright 2017 All Rights Reserved </h1>
</div>

</body>


</html>